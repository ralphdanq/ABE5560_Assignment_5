# -*- coding: utf-8 -*-
# Park_Distribution.pyt
#
# Author: Ralph Danquah-Acquah, danquahr@iastate.edu
# Last modified: November 22, 2026
# Python version: Python 3.13.7 (ArcGIS Pro 3.6)
# Purpose:
# Analyze access to parks and other public open space for a selected Iowa city.
# The tool selects a city, extracts park polygons from the statewide Iowa OSM
# Points of Interest dataset, clips parks and public lands to the city analysis
# area, calculates open-space accessibility for census blocks, and writes the
# final census-block results to an output feature class.
#

import arcpy
import sys
import time
import traceback


class Toolbox(object):
    def __init__(self):
        """Define the toolbox."""
        self.label = "Park_Provisions"
        self.alias = "parksAndOpenSpace"

        # List of tool classes associated with this toolbox
        self.tools = [ParkProvisions]


class ParkProvisions(object):
    def __init__(self):
        """Define the Park Provisions tool."""
        self.label = "Park Provisions"
        self.description = (
            "Analyzes access to parks and other public open space "
            "for a selected Iowa city."
        )
        self.canRunInBackground = False
        self.category = "Distribution"

    def getParameterInfo(self):
        """Define parameter definitions."""

        # Input 0: Iowa incorporated city boundaries
        param0 = arcpy.Parameter(
            displayName="City Boundaries",
            name="city_boundaries",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input"
        )

        # Input 1: Iowa 2010 census blocks
        param1 = arcpy.Parameter(
            displayName="Census Blocks",
            name="census_blocks",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input"
        )

        # Input 2: statewide Iowa OSM polygon points-of-interest dataset
        param2 = arcpy.Parameter(
            displayName="Statewide OSM Points of Interest",
            name="statewide_osm_pois",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input"
        )

        # Input 3: state and county public lands
        param3 = arcpy.Parameter(
            displayName="Public Lands",
            name="public_lands",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input"
        )

        # Input 4: walking-distance threshold
        param4 = arcpy.Parameter(
            displayName="Buffer Distance in meters",
            name="buffer_dist",
            datatype="GPDouble",
            parameterType="Required",
            direction="Input"
        )

        # Input 5: city name. Ankeny is the Assignment 5 graded run.
        param5 = arcpy.Parameter(
            displayName="City Name to Select",
            name="city_name",
            datatype="GPString",
            parameterType="Required",
            direction="Input"
        )

        # Output 6: final census-block accessibility results
        param6 = arcpy.Parameter(
            displayName="Output Features",
            name="output_features",
            datatype="DEFeatureClass",
            parameterType="Required",
            direction="Output"
        )

        # Lecture 21B-style filtering and defaults
        param4.filter.type = "Range"
        param4.filter.list = [1, 5000]
        param4.value = 1000
        param5.value = "Ankeny"

        params = [
            param0,
            param1,
            param2,
            param3,
            param4,
            param5,
            param6
        ]

        return params

    def isLicensed(self):
        """Set whether the tool is licensed to execute."""
        return True

    def updateParameters(self, parameters):
        """Modify parameter values before internal validation."""
        return

    def updateMessages(self, parameters):
        """Modify messages after internal validation."""
        return

    def execute(self, parameters, messages):
        """Run the park and open-space accessibility analysis."""

        start = time.perf_counter()

        try:
            arcpy.AddMessage("Starting Park Provisions analysis")

            # ----------------------------------------------------------
            # Read toolbox parameters
            # ----------------------------------------------------------

            # All incorporated city boundaries for Iowa
            city_boundaries = parameters[0].valueAsText

            # US Census blocks for Iowa from 2010
            state_census = parameters[1].valueAsText

            # Statewide OSM Points of Interest polygon dataset
            statewide_osm_pois = parameters[2].valueAsText

            # State and county public lands
            public_lands = parameters[3].valueAsText

            # Buffer distance entered as a number. Lecture 21B uses meters.
            buff_value = parameters[4].valueAsText
            buff_dist = str(buff_value) + " METERS"

            # City remains a variable so the same tool works for other cities.
            cityName = parameters[5].valueAsText

            # Final output feature class
            output_fc = parameters[6].valueAsText

            # ----------------------------------------------------------
            # Set up environments
            # ----------------------------------------------------------

            arcpy.env.scratchWorkspace = "in_memory"
            arcpy.env.workspace = "in_memory"
            arcpy.env.overwriteOutput = True

            # The original course datasets use NAD 1983 UTM Zone 15N.
            # The Assignment 5 OSM dataset is geographic WGS 1984, so use
            # the city-boundary coordinate system for intermediate outputs.
            city_sr = arcpy.Describe(city_boundaries).spatialReference
            arcpy.env.outputCoordinateSystem = city_sr

            arcpy.AddMessage(
                "Scratch workspace is " + str(arcpy.env.scratchWorkspace)
            )

            # ----------------------------------------------------------
            # Select the requested city
            # ----------------------------------------------------------

            arcpy.AddMessage("Selecting city: " + cityName)

            city_where = (
                arcpy.AddFieldDelimiters(city_boundaries, "NAME10")
                + " = '"
                + cityName.replace("'", "''")
                + "'"
            )

            cityBoundary = arcpy.Select_analysis(
                city_boundaries,
                r"in_memory\cityBoundary",
                city_where
            )

            # ----------------------------------------------------------
            # Buffer the city to include open space near city limits
            # ----------------------------------------------------------

            arcpy.AddMessage("Buffering city boundary")

            cityBoundaryBuffer = arcpy.Buffer_analysis(
                cityBoundary,
                r"in_memory\cityBoundaryBuffer",
                buff_dist
            )

            # ----------------------------------------------------------
            # Assignment 5 change:
            # Extract only parks from the statewide OSM POI dataset
            # ----------------------------------------------------------

            arcpy.AddMessage("Selecting parks from statewide OSM POIs")

            park_where = (
                arcpy.AddFieldDelimiters(statewide_osm_pois, "fclass")
                + " = 'park'"
            )

            selectedParks = arcpy.Select_analysis(
                statewide_osm_pois,
                r"in_memory\selectedParks",
                park_where
            )

            # ----------------------------------------------------------
            # Assignment 5 change:
            # Clip the selected parks to the buffered city boundary
            # ----------------------------------------------------------

            arcpy.AddMessage("Clipping OSM parks to the city buffer")

            cityParks = arcpy.Clip_analysis(
                selectedParks,
                cityBoundaryBuffer,
                r"in_memory\cityParks"
            )

            # ----------------------------------------------------------
            # Clip census blocks to the selected city
            # ----------------------------------------------------------

            arcpy.AddMessage("Clipping census blocks")

            cityCensusBlocks = arcpy.Clip_analysis(
                state_census,
                cityBoundary,
                r"in_memory\cityCensusBlocks"
            )

            # ----------------------------------------------------------
            # Clip public lands to the buffered city boundary
            # ----------------------------------------------------------

            arcpy.AddMessage("Clipping public lands")

            cityPublicLands = arcpy.Clip_analysis(
                public_lands,
                cityBoundaryBuffer,
                r"in_memory\cityPublicLands"
            )

            # ----------------------------------------------------------
            # Merge parks and other public open lands
            # ----------------------------------------------------------

            arcpy.AddMessage("Merging parks and public lands")

            openMerge = arcpy.Merge_management(
                [cityParks, cityPublicLands],
                r"in_memory\openMerge"
            )

            # ----------------------------------------------------------
            # Buffer open space by the walking-distance threshold
            # ----------------------------------------------------------

            arcpy.AddMessage("Buffering open space")

            cityPublicBuffer = arcpy.Buffer_analysis(
                openMerge,
                r"in_memory\cityPublicBuffer",
                buff_dist
            )

            # Intersect buffered open space with census blocks
            arcpy.AddMessage(
                "Intersecting open-space buffers with census blocks"
            )

            cityIntersectBuffer = arcpy.Intersect_analysis(
                [cityCensusBlocks, cityPublicBuffer],
                r"in_memory\cityIntersectBuffer"
            )

            # ----------------------------------------------------------
            # Add fields used by the first accessibility method
            # ----------------------------------------------------------

            # Total area of each census block within walking distance
            addAccess = arcpy.AddField_management(
                cityCensusBlocks,
                "BLK_ACCESS",
                "DOUBLE",
                10,
                3
            )

            # Accessible area divided by total census-block area
            addFrac = arcpy.AddField_management(
                cityCensusBlocks,
                "ACC_FRAC",
                "DOUBLE",
                10,
                3
            )

            arcpy.AddMessage(
                "Census blocks: "
                + str(
                    [fld.name for fld in arcpy.ListFields(cityCensusBlocks)]
                )
            )

            # ----------------------------------------------------------
            # Lecture 21 progressor
            # ----------------------------------------------------------

            row_count = int(
                arcpy.GetCount_management(
                    cityCensusBlocks
                ).getOutput(0)
            )

            i = 0

            arcpy.SetProgressor(
                "step",
                "Processing Census Blocks...",
                0,
                row_count,
                1
            )

            arcpy.AddMessage("Starting census-block calculations")

            # ----------------------------------------------------------
            # Calculate accessible area and access fraction by block
            # ----------------------------------------------------------

            update_fields = [
                "GEOID10",
                addAccess.getInput(1),
                addFrac.getInput(1),
                "SHAPE@AREA"
            ]

            with arcpy.da.UpdateCursor(
                cityCensusBlocks,
                update_fields
            ) as ucur:

                for urow in ucur:

                    arcpy.SetProgressorLabel(
                        "Processing Census Block #" + str(i)
                    )
                    arcpy.SetProgressorPosition()

                    cumulative_area = 0.0

                    block_where = (
                        arcpy.AddFieldDelimiters(
                            cityIntersectBuffer,
                            "GEOID10"
                        )
                        + " = '"
                        + str(urow[0]).replace("'", "''")
                        + "'"
                    )

                    # A census block may intersect more than one
                    # open-space buffer, so sum all matching areas.
                    with arcpy.da.SearchCursor(
                        cityIntersectBuffer,
                        ["SHAPE@AREA"],
                        block_where
                    ) as scur:

                        for srow in scur:
                            cumulative_area += srow[0]

                    # Store total accessible area.
                    urow[1] = cumulative_area

                    # Normalize by total census-block area.
                    urow[2] = cumulative_area / urow[3]

                    # Commit the updated values.
                    ucur.updateRow(urow)

                    i += 1

            arcpy.ResetProgressor()

            # ----------------------------------------------------------
            # Second accessibility method:
            # Generate Near Table and inverse distance
            # ----------------------------------------------------------

            arcpy.AddMessage(
                "Calculating distance from blocks to open space"
            )

            gnt = arcpy.GenerateNearTable_analysis(
                cityCensusBlocks,
                openMerge,
                r"in_memory\nearTable",
                search_radius=buff_dist,
                closest="ALL"
            )

            addInv = arcpy.AddField_management(
                gnt,
                "INV_DIST",
                "DOUBLE"
            )

            arcpy.CalculateField_management(
                gnt,
                addInv.getInput(1),
                str(buff_value) + " - !NEAR_DIST!",
                "PYTHON3"
            )

            arcpy.AddMessage(
                "Running statistics on the distance-based method"
            )

            stats = arcpy.Statistics_analysis(
                gnt,
                r"in_memory\nearStats",
                statistics_fields=[
                    [addInv.getInput(1), "SUM"]
                ],
                case_field="IN_FID"
            )

            # Join the summed inverse-distance statistic back to
            # the corresponding census blocks.
            descCensus = arcpy.Describe(cityCensusBlocks)

            sumField = (
                stats.getInput(1).split()[1]
                + "_"
                + addInv.getInput(1)
            )

            arcpy.JoinField_management(
                cityCensusBlocks,
                descCensus.OIDFieldName,
                stats,
                "IN_FID",
                [sumField]
            )

            # ----------------------------------------------------------
            # Save final results
            # ----------------------------------------------------------

            arcpy.AddMessage("Copying final results")

            arcpy.CopyFeatures_management(
                cityCensusBlocks,
                output_fc
            )

            arcpy.AddMessage(
                "Finished. Output saved to: " + output_fc
            )

        except Exception:
            tb = sys.exc_info()[2]
            tbinfo = "".join(traceback.format_tb(tb))

            pymsg = (
                "PYTHON ERRORS:\n"
                "Traceback info:\n"
                + tbinfo
                + "\nError Info:\n"
                + str(sys.exc_info()[1])
            )

            arcpy.AddError(pymsg)

            if arcpy.GetMessages(2) not in pymsg:
                msgs = (
                    "ArcPy ERRORS:\n"
                    + arcpy.GetMessages(2)
                    + "\n"
                )
                arcpy.AddError(msgs)

            raise

        finally:
            arcpy.ResetProgressor()
            end = time.perf_counter()
            arcpy.AddMessage(
                "Execution took: "
                + str(end - start)
                + " seconds"
            )
